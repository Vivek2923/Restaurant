﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantCRM
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using (CrmServiceClient svcClient = new CrmServiceClient(ConfigurationManager.ConnectionStrings["Restaurantconnection"].ConnectionString))
            {
                if (!svcClient.IsReady)
                {
                    Console.WriteLine("unable to connect!");
                    return;
                }
                else
                {
                    WhoAmIRequest request = new WhoAmIRequest();
                    WhoAmIResponse response = (WhoAmIResponse)svcClient.Execute(request);
                    Console.WriteLine("Dynamic CRM 365 Connected....");
                    Console.WriteLine("UserId =" + response.UserId.ToString());
                    return;
                }                

            }
        }
    }
}
