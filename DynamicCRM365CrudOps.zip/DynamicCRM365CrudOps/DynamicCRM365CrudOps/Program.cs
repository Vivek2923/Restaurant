﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;

class Program
{
    // TODO Enter your Dataverse environment's URL and logon info.
    static string url = "https://orgc14752dd.crm.dynamics.com/";
    static string userName = "vibhav.290989@vbtech.onmicrosoft.com";
    static string password = "Svb@9600020247";

    // This service connection string uses the info provided above.
    // The AppId and RedirectUri are provided for sample code testing.
    static string connectionString = $@"
    AuthType = OAuth;
    Url = {url};
    UserName = {userName};
    Password = {password};
    AppId = 288f32ef-1a51-4bde-94dc-52e3e6592a58;
    RedirectUri = http://localhost;
    LoginPrompt=Auto;
    RequireNewInstance = True";

    static void Main(string[] args)
    {
        using (ServiceClient serviceClient = new(connectionString))
        {
            if (serviceClient.IsReady)
            {
                WhoAmIResponse response =
                    (WhoAmIResponse)serviceClient.Execute(new WhoAmIRequest());

                Console.WriteLine("User ID is {0}.", response.UserId);
                CrmServiceClient svc = new CrmServiceClient(connectionString);
                if (svc.IsReady)
                {
                    Console.WriteLine("Connected to Dynamic 365 ....");
                    PerformCRUD(svc);
                }
            }
            else
            {
                Console.WriteLine(
                    "A web service connection was not established.");
            }
        }

        // Pause the console so it does not close.
        Console.WriteLine("Press any key to exit.");
        Console.ReadLine();
    }

    public CrmServiceClient ConnectWithOAuth()
    {
        Console.WriteLine("Connecting to D365 Server...");
        string authType = "OAuth";
        string userName = "vibhav.290989@vbtech.onmicrosoft.com";
        string password = "Svb@9600020247";
        string url = "https://orgc14752dd.crm.dynamics.com/";
        string appId = "288f32ef-1a51-4bde-94dc-52e3e6592a58";
        string reDirectURI = "https://localhost";
        string loginPrompt = "Auto";
        string ConnectionString = string.Format("AuthType = {0};Username = {1};Password = {2}; Url = {3}; AppId={4}; RedirectUri={5};LoginPrompt={6}",
                                                authType, userName, password, url, appId, reDirectURI, loginPrompt);

        CrmServiceClient svc = new CrmServiceClient(ConnectionString);
        return svc;
    }
    public static void PerformCRUD(CrmServiceClient svc)
    {
        //CREATE
        var myContact = new Entity("contact");
        myContact.Attributes["lastname"] = "Learn";
        myContact.Attributes["firstname"] = "Softchief";
        myContact.Attributes["jobtitle"] = "Consultant";
        Guid RecordID = svc.Create(myContact);
        Console.WriteLine("Contact create with ID - " + RecordID);

        //RETRIEVE  
        Entity contact = svc.Retrieve("contact", new Guid("df4df113-746c-eb11-a812-000d3a3b1114"), new ColumnSet("firstname", "lastname"));
        Console.WriteLine("Contact lastname is - " + contact.Attributes["lastname"]);

        //Retrieve Multiple Record
        QueryExpression qe = new QueryExpression("contact");
        qe.ColumnSet = new ColumnSet("firstname", "lastname");
        EntityCollection ec = svc.RetrieveMultiple(qe);

        for (int i = 0; i < ec.Entities.Count; i++)
        {
            if (ec.Entities[i].Attributes.ContainsKey("firstname"))
            {
                Console.WriteLine(ec.Entities[i].Attributes["firstname"]);
            }
        }
        Console.WriteLine("Retrieved all Contacts...");

        //UPDATE
        Entity entContact = new Entity("contact");
        entContact.Id = RecordID;
        entContact.Attributes["lastname"] = "Facts";
        svc.Update(entContact);
        Console.WriteLine("Contact lastname updated");


        //DELETE
        svc.Delete("contact", RecordID);

        //Execute
        Entity acc = new Entity("account");
        acc["name"] = "Soft";
        var createRequest = new CreateRequest()
        {
            Target = acc
        };
        svc.Execute(createRequest);


        //Execute Multiple
        var request = new ExecuteMultipleRequest()
        {
            Requests = new OrganizationRequestCollection(),
            Settings = new ExecuteMultipleSettings
            {
                ContinueOnError = false,
                ReturnResponses = true
            }
        };

        Entity acc1 = new Entity("account");
        acc1["name"] = "Soft1";
        Entity acc2 = new Entity("account");
        acc2["name"] = "Soft2";

        var createRequest1 = new CreateRequest()
        {
            Target = acc1
        };
        var createRequest2 = new CreateRequest()
        {
            Target = acc2
        };

        request.Requests.Add(createRequest1);
        request.Requests.Add(createRequest2);
        var response = (ExecuteMultipleResponse)svc.Execute(request);

    }
}